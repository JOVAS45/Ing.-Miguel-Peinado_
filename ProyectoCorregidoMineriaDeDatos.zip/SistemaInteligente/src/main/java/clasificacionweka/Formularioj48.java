package clasificacionweka;

import javax.swing.*;
import java.awt.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import java.util.ArrayList;
import java.io.File;

public class Formularioj48 extends JFrame {
    private JComboBox<String> cmbCheckingStatus, cmbCreditHistory, cmbPurpose;
    private JComboBox<String> cmbSavingsStatus, cmbEmployment, cmbPersonalStatus;
    private JComboBox<String> cmbOtherDebtors, cmbProperty, cmbInstallmentPlans;
    private JComboBox<String> cmbHousing, cmbJob, cmbTelephone, cmbForeignWorker;

    private JTextField txtDuration, txtCreditAmount, txtInstallmentRate;
    private JTextField txtResidenceDuration, txtAge, txtExistingCredits, txtDependents;

    private JTextArea txtResultado;
    private JPanel panelGrafico;
    private ClasificacionJ48 clasificador;


    private final String[] valoresChecking = {"<0", "0<=X<200", ">=200", "no checking"};
    private final String[] valoresCreditHistory = {"no credits/all paid", "all paid", "existing paid", "delayed previously", "critical/other existing credit"};
    private final String[] valoresPurpose = {"new car", "used car", "furniture", "radio/tv", "domestic appliance", "repairs", "education", "vacation", "retraining", "business", "other"};
    private final String[] valoresSavings = {"<100", "100<=X<500", "500<=X<1000", ">=1000", "no known savings"};
    private final String[] valoresEmployment = {"unemployed", ">=7", "4<=X<7", "1<=X<4", "<1"};
    private final String[] valoresPersonal = {"male div/sep", "female div/dep/mar", "male single", "male mar/wid", "female single"};
    private final String[] valoresDebtors = {"none", "co applicant", "guarantor"};
    private final String[] valoresProperty = {"real estate", "life insurance", "car", "no known property"};
    private final String[] valoresPlanes = {"bank", "stores", "none"};
    private final String[] valoresHousing = {"rent", "own", "for free"};
    private final String[] valoresJob = {"unemp/unskilled non res", "unskilled resident", "skilled", "high qualif/self emp/mgmt"};
    private final String[] valoresTelefono = {"none", "yes"};
    private final String[] valoresForeign = {"yes", "no"};

    public Formularioj48() {
        clasificador = new ClasificacionJ48();
        inicializarComponentes();
        cargarModelo();
    }

    private void inicializarComponentes() {
        setTitle("Sistema de Clasificación de Crédito");
        setLayout(new BorderLayout(10, 10));


        JTabbedPane tabbedPane = new JTabbedPane();


        JPanel panelEntrada = crearPanelEntrada();
        tabbedPane.addTab("Entrada de Datos", new JScrollPane(panelEntrada));

        // Panel de gráficos
        panelGrafico = new JPanel(new BorderLayout());
        tabbedPane.addTab("Gráficos", panelGrafico);


        JPanel panelBotones = new JPanel();
        JButton btnEntrenar = new JButton("Entrenar Modelo");

        JButton btnClasificar = new JButton("Clasificar");
        JButton btnLimpiar = new JButton("Limpiar");

        btnEntrenar.addActionListener(e -> entrenarModelo());

        btnClasificar.addActionListener(e -> clasificar());
        btnLimpiar.addActionListener(e -> limpiarCampos());

        panelBotones.add(btnEntrenar);

        panelBotones.add(btnClasificar);
        panelBotones.add(btnLimpiar);


        txtResultado = new JTextArea(10, 40);
        txtResultado.setEditable(false);
        JScrollPane scrollResultado = new JScrollPane(txtResultado);


        add(tabbedPane, BorderLayout.CENTER);
        add(scrollResultado, BorderLayout.EAST);
        add(panelBotones, BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
    }

    private JPanel crearPanelEntrada() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 4, 4, 4);


        cmbCheckingStatus = new JComboBox<>(valoresChecking);
        cmbCreditHistory = new JComboBox<>(valoresCreditHistory);
        cmbPurpose = new JComboBox<>(valoresPurpose);
        cmbSavingsStatus = new JComboBox<>(valoresSavings);
        cmbEmployment = new JComboBox<>(valoresEmployment);
        cmbPersonalStatus = new JComboBox<>(valoresPersonal);
        cmbOtherDebtors = new JComboBox<>(valoresDebtors);
        cmbProperty = new JComboBox<>(valoresProperty);
        cmbInstallmentPlans = new JComboBox<>(valoresPlanes);
        cmbHousing = new JComboBox<>(valoresHousing);
        cmbJob = new JComboBox<>(valoresJob);
        cmbTelephone = new JComboBox<>(valoresTelefono);
        cmbForeignWorker = new JComboBox<>(valoresForeign);


        txtDuration = new JTextField(10);
        txtCreditAmount = new JTextField(10);
        txtInstallmentRate = new JTextField(10);
        txtResidenceDuration = new JTextField(10);
        txtAge = new JTextField(10);
        txtExistingCredits = new JTextField(10);
        txtDependents = new JTextField(10);

        int y = 0;

        agregarCampo("Estado de cuenta:", cmbCheckingStatus, gbc, panel, y++);
        agregarCampo("Duración (meses):", txtDuration, gbc, panel, y++);
        agregarCampo("Historial crediticio:", cmbCreditHistory, gbc, panel, y++);
        agregarCampo("Propósito:", cmbPurpose, gbc, panel, y++);
        agregarCampo("Monto del crédito:", txtCreditAmount, gbc, panel, y++);
        agregarCampo("Estado de ahorros:", cmbSavingsStatus, gbc, panel, y++);
        agregarCampo("Empleo:", cmbEmployment, gbc, panel, y++);
        agregarCampo("Tasa de instalación:", txtInstallmentRate, gbc, panel, y++);
        agregarCampo("Estado personal:", cmbPersonalStatus, gbc, panel, y++);
        agregarCampo("Otros deudores:", cmbOtherDebtors, gbc, panel, y++);
        agregarCampo("Duración residencia:", txtResidenceDuration, gbc, panel, y++);
        agregarCampo("Propiedad:", cmbProperty, gbc, panel, y++);
        agregarCampo("Edad:", txtAge, gbc, panel, y++);
        agregarCampo("Planes instalación:", cmbInstallmentPlans, gbc, panel, y++);
        agregarCampo("Vivienda:", cmbHousing, gbc, panel, y++);
        agregarCampo("Créditos existentes:", txtExistingCredits, gbc, panel, y++);
        agregarCampo("Trabajo:", cmbJob, gbc, panel, y++);
        agregarCampo("Dependientes:", txtDependents, gbc, panel, y++);
        agregarCampo("Teléfono:", cmbTelephone, gbc, panel, y++);
        agregarCampo("Trabajador extranjero:", cmbForeignWorker, gbc, panel, y++);

        return panel;
    }

    private void agregarCampo(String etiqueta, JComponent campo, GridBagConstraints gbc, JPanel panel, int y) {
        gbc.gridx = 0;
        gbc.gridy = y;
        panel.add(new JLabel(etiqueta), gbc);
        gbc.gridx = 1;
        panel.add(campo, gbc);
    }

    private void cargarModelo() {
        try {
            clasificador.cargarDatos("D:\\Projects\\arff-dataset\\arff-datasets-master\\classification\\credit.g.arff");
            txtResultado.setText("Modelo cargado exitosamente");
        } catch (Exception e) {
            mostrarError("Error al cargar el modelo: " + e.getMessage());
        }
    }

    private void entrenarModelo() {
        try {
            clasificador.entrenarModelo();
            txtResultado.setText(clasificador.obtenerResultadosEntrenamiento());
            actualizarGrafico(clasificador.getPrecision(), clasificador.getError());
        } catch (Exception e) {
            mostrarError("Error al entrenar el modelo: " + e.getMessage());
        }
    }

    private void clasificar() {
        if (!validarCamposNumericos()) {
            return;
        }

        try {
            ArrayList<String> valores = recogerValores();
            String resultado = clasificador.clasificarInstancia(valores);

            String mensaje;
            if (resultado.equalsIgnoreCase("bad")) {
                mensaje = "CRÉDITO NO APROBADO\n\n" +
                        "Lo sentimos, basado en los datos proporcionados, " +
                        "su solicitud de crédito ha sido rechazada.";
            } else if (resultado.equalsIgnoreCase("good")) {
                mensaje = "CRÉDITO APROBADO\n\n" +
                        "¡Felicitaciones! Su solicitud de crédito ha sido aprobada " +
                        "según el análisis realizado.";
            } else {
                mensaje = "Resultado de la clasificación: " + resultado;
            }

            txtResultado.setText(mensaje);

        } catch (Exception e) {
            mostrarError("Error al clasificar: " + e.getMessage());
        }
    }

    private ArrayList<String> recogerValores() {
        ArrayList<String> valores = new ArrayList<>();
        valores.add((String) cmbCheckingStatus.getSelectedItem());
        valores.add(txtDuration.getText());
        valores.add((String) cmbCreditHistory.getSelectedItem());
        valores.add((String) cmbPurpose.getSelectedItem());
        valores.add(txtCreditAmount.getText());
        valores.add((String) cmbSavingsStatus.getSelectedItem());
        valores.add((String) cmbEmployment.getSelectedItem());
        valores.add(txtInstallmentRate.getText());
        valores.add((String) cmbPersonalStatus.getSelectedItem());
        valores.add((String) cmbOtherDebtors.getSelectedItem());
        valores.add(txtResidenceDuration.getText());
        valores.add((String) cmbProperty.getSelectedItem());
        valores.add(txtAge.getText());
        valores.add((String) cmbInstallmentPlans.getSelectedItem());
        valores.add((String) cmbHousing.getSelectedItem());
        valores.add(txtExistingCredits.getText());
        valores.add((String) cmbJob.getSelectedItem());
        valores.add(txtDependents.getText());
        valores.add((String) cmbTelephone.getSelectedItem());
        valores.add((String) cmbForeignWorker.getSelectedItem());
        return valores;
    }

    private void actualizarGrafico(double precision, double error) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(precision, "Métricas", "Precisión");
        dataset.addValue(error, "Métricas", "Error");

        JFreeChart chart = ChartFactory.createBarChart(
                "Rendimiento del Modelo",
                "Métrica",
                "Porcentaje",
                dataset
        );

        panelGrafico.removeAll();
        panelGrafico.add(new ChartPanel(chart));
        panelGrafico.revalidate();
    }

    private boolean validarCamposNumericos() {
        try {
            if (!txtDuration.getText().trim().isEmpty())
                Integer.parseInt(txtDuration.getText().trim());
            if (!txtCreditAmount.getText().trim().isEmpty())
                Double.parseDouble(txtCreditAmount.getText().trim());
            if (!txtInstallmentRate.getText().trim().isEmpty())
                Integer.parseInt(txtInstallmentRate.getText().trim());
            if (!txtResidenceDuration.getText().trim().isEmpty())
                Integer.parseInt(txtResidenceDuration.getText().trim());
            if (!txtAge.getText().trim().isEmpty())
                Integer.parseInt(txtAge.getText().trim());
            if (!txtExistingCredits.getText().trim().isEmpty())
                Integer.parseInt(txtExistingCredits.getText().trim());
            if (!txtDependents.getText().trim().isEmpty())
                Integer.parseInt(txtDependents.getText().trim());
            return true;
        } catch (NumberFormatException e) {
            mostrarError("Por favor, ingrese valores numéricos válidos");
            return false;
        }
    }

    private void guardarModelo() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                clasificador.guardarModelo(file.getAbsolutePath());
                txtResultado.setText("Modelo guardado exitosamente en: " + file.getAbsolutePath());
            }
        } catch (Exception e) {
            mostrarError("Error al guardar el modelo: " + e.getMessage());
        }
    }

    private void cargarModeloGuardado() {
        try {
            JFileChooser fileChooser = new JFileChooser();
            if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                clasificador.cargarModeloGuardado(file.getAbsolutePath());
                txtResultado.setText("Modelo cargado exitosamente desde: " + file.getAbsolutePath());
            }
        } catch (Exception e) {
            mostrarError("Error al cargar el modelo: " + e.getMessage());
        }
    }

    private void limpiarCampos() {
        txtDuration.setText("");
        txtCreditAmount.setText("");
        txtInstallmentRate.setText("");
        txtResidenceDuration.setText("");
        txtAge.setText("");
        txtExistingCredits.setText("");
        txtDependents.setText("");
        cmbCheckingStatus.setSelectedIndex(0);
        cmbCreditHistory.setSelectedIndex(0);
        cmbPurpose.setSelectedIndex(0);
        cmbSavingsStatus.setSelectedIndex(0);
        cmbEmployment.setSelectedIndex(0);
        cmbPersonalStatus.setSelectedIndex(0);
        cmbOtherDebtors.setSelectedIndex(0);
        cmbProperty.setSelectedIndex(0);
        cmbInstallmentPlans.setSelectedIndex(0);
        cmbHousing.setSelectedIndex(0);
        cmbJob.setSelectedIndex(0);
        cmbTelephone.setSelectedIndex(0);
        cmbForeignWorker.setSelectedIndex(0);

        txtResultado.setText("");

        // Limpiar el gráfico
        if (panelGrafico != null) {
            panelGrafico.removeAll();
            panelGrafico.revalidate();
            panelGrafico.repaint();
        }
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void mostrarInformacion(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Información", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        try {
            // Establecer el look and feel del sistema
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            Formularioj48 formulario = new Formularioj48();
            formulario.setVisible(true);
        });
    }
}