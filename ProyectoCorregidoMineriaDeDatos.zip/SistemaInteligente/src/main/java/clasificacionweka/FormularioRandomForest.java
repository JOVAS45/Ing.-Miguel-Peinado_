package clasificacionweka;

import javax.swing.*;
import java.awt.*;
import weka.core.Instances;
import java.util.ArrayList;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

public class FormularioRandomForest extends JFrame {
    private JComboBox<String> cmbCheckingStatus, cmbCreditHistory, cmbPurpose;
    private JComboBox<String> cmbSavingsStatus, cmbEmployment, cmbPersonalStatus;
    private JComboBox<String> cmbOtherDebtors, cmbProperty, cmbInstallmentPlans;
    private JComboBox<String> cmbHousing, cmbJob, cmbTelephone, cmbForeignWorker;

    private JTextField txtDuration, txtCreditAmount, txtInstallmentRate;
    private JTextField txtResidenceDuration, txtAge, txtExistingCredits, txtDependents;

    private JTextArea txtResultado;
    private JPanel panelGrafico;
    private ClasificacionRandomForest clasificador;

    public FormularioRandomForest() {
        clasificador = new ClasificacionRandomForest();
        inicializarComponentes();
        cargarModelo();
    }

    private void inicializarComponentes() {
        setTitle("Sistema de Clasificación de Crédito - Random Forest");
        setLayout(new BorderLayout(10, 10));

        JTabbedPane tabbedPane = new JTabbedPane();

        JPanel panelEntrada = crearPanelEntrada();
        tabbedPane.addTab("Entrada de Datos", new JScrollPane(panelEntrada));

        panelGrafico = new JPanel(new BorderLayout());
        tabbedPane.addTab("Gráficos", panelGrafico);

        JPanel panelBotones = crearPanelBotones();

        txtResultado = new JTextArea(10, 40);
        txtResultado.setEditable(false);
        JScrollPane scrollResultado = new JScrollPane(txtResultado);

        add(tabbedPane, BorderLayout.CENTER);
        add(scrollResultado, BorderLayout.EAST);
        add(panelBotones, BorderLayout.SOUTH);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
    }

    private JPanel crearPanelEntrada() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(4, 4, 4, 4);

        // Inicializar ComboBoxes
        cmbCheckingStatus = new JComboBox<>();
        cmbCreditHistory = new JComboBox<>();
        cmbPurpose = new JComboBox<>();
        cmbSavingsStatus = new JComboBox<>();
        cmbEmployment = new JComboBox<>();
        cmbPersonalStatus = new JComboBox<>();
        cmbOtherDebtors = new JComboBox<>();
        cmbProperty = new JComboBox<>();
        cmbInstallmentPlans = new JComboBox<>();
        cmbHousing = new JComboBox<>();
        cmbJob = new JComboBox<>();
        cmbTelephone = new JComboBox<>();
        cmbForeignWorker = new JComboBox<>();

        // Campos numéricos
        txtDuration = new JTextField(10);
        txtCreditAmount = new JTextField(10);
        txtInstallmentRate = new JTextField(10);
        txtResidenceDuration = new JTextField(10);
        txtAge = new JTextField(10);
        txtExistingCredits = new JTextField(10);
        txtDependents = new JTextField(10);

        int y = 0;
        agregarCampo("Estado de cuenta:", cmbCheckingStatus, gbc, panel, y++);
        agregarCampo("Duración (meses):", txtDuration, gbc, panel, y++);
        agregarCampo("Historial crediticio:", cmbCreditHistory, gbc, panel, y++);
        agregarCampo("Propósito:", cmbPurpose, gbc, panel, y++);
        agregarCampo("Monto del crédito:", txtCreditAmount, gbc, panel, y++);
        agregarCampo("Estado de ahorros:", cmbSavingsStatus, gbc, panel, y++);
        agregarCampo("Empleo:", cmbEmployment, gbc, panel, y++);
        agregarCampo("Tasa de instalación:", txtInstallmentRate, gbc, panel, y++);
        agregarCampo("Estado personal:", cmbPersonalStatus, gbc, panel, y++);
        agregarCampo("Otros deudores:", cmbOtherDebtors, gbc, panel, y++);
        agregarCampo("Duración residencia:", txtResidenceDuration, gbc, panel, y++);
        agregarCampo("Propiedad:", cmbProperty, gbc, panel, y++);
        agregarCampo("Edad:", txtAge, gbc, panel, y++);
        agregarCampo("Planes instalación:", cmbInstallmentPlans, gbc, panel, y++);
        agregarCampo("Vivienda:", cmbHousing, gbc, panel, y++);
        agregarCampo("Créditos existentes:", txtExistingCredits, gbc, panel, y++);
        agregarCampo("Trabajo:", cmbJob, gbc, panel, y++);
        agregarCampo("Dependientes:", txtDependents, gbc, panel, y++);
        agregarCampo("Teléfono:", cmbTelephone, gbc, panel, y++);
        agregarCampo("Trabajador extranjero:", cmbForeignWorker, gbc, panel, y++);

        return panel;
    }
    private JPanel crearPanelBotones() {
        JPanel panel = new JPanel();
        JButton btnEntrenar = new JButton("Entrenar Modelo");
        JButton btnClasificar = new JButton("Clasificar");
        JButton btnLimpiar = new JButton("Limpiar");

        btnEntrenar.addActionListener(e -> entrenarModelo());
        btnClasificar.addActionListener(e -> clasificar());
        btnLimpiar.addActionListener(e -> limpiarCampos());

        panel.add(btnEntrenar);
        panel.add(btnClasificar);
        panel.add(btnLimpiar);

        return panel;
    }

    private void agregarCampo(String etiqueta, JComponent campo, GridBagConstraints gbc, JPanel panel, int y) {
        gbc.gridx = 0;
        gbc.gridy = y;
        panel.add(new JLabel(etiqueta), gbc);
        gbc.gridx = 1;
        panel.add(campo, gbc);
    }

    private void cargarModelo() {
        try {
            clasificador.cargarDatos("D:\\Projects\\arff-dataset\\arff-datasets-master\\classification\\credit.g.arff");
            System.out.println("Cargando atributos del dataset:");
            clasificador.imprimirNombresAtributos();
            actualizarComboBoxes();
            txtResultado.setText(clasificador.obtenerResultadosEntrenamiento());
        } catch (Exception e) {
            mostrarError("Error al cargar el modelo: " + e.getMessage());
        }
    }

    private void actualizarComboBoxes() {
        try {
            Instances dataset = clasificador.getDatos();
            for (int i = 0; i < dataset.numAttributes(); i++) {
                if (dataset.attribute(i).isNominal()) {
                    JComboBox<String> comboBox = obtenerComboBoxPorAtributo(dataset.attribute(i).name());
                    if (comboBox != null) {
                        comboBox.removeAllItems();
                        for (int j = 0; j < dataset.attribute(i).numValues(); j++) {
                            comboBox.addItem(dataset.attribute(i).value(j));
                        }
                    }
                }
            }
        } catch (Exception e) {
            mostrarError("Error al actualizar ComboBoxes: " + e.getMessage());
        }
    }

    private JComboBox<String> obtenerComboBoxPorAtributo(String nombreAtributo) {
        switch (nombreAtributo.toLowerCase()) {
            case "checking_status": return cmbCheckingStatus;
            case "credit_history": return cmbCreditHistory;
            case "purpose": return cmbPurpose;
            case "savings_status": return cmbSavingsStatus;
            case "employment": return cmbEmployment;
            case "personal_status": return cmbPersonalStatus;
                case "other_parties": return cmbOtherDebtors;
            case "property_magnitude": return cmbProperty;
            case "other_payment_plans": return cmbInstallmentPlans;
            case "housing": return cmbHousing;
            case "job": return cmbJob;
            case "own_telephone": return cmbTelephone;
            case "foreign_worker": return cmbForeignWorker;
            default:
                System.out.println("Atributo no encontrado: " + nombreAtributo);
                return null;
        }
    }

    private void entrenarModelo() {
        try {
            clasificador.entrenarModelo();
            txtResultado.setText(clasificador.obtenerResultadosEntrenamiento());
            actualizarGrafico(clasificador.getPrecision(), clasificador.getError());
        } catch (Exception e) {
            mostrarError("Error al entrenar el modelo: " + e.getMessage());
        }
    }

    private ArrayList<String> recogerValores() {
        ArrayList<String> valores = new ArrayList<>();
        Instances dataset = clasificador.getDatos();

        for (int i = 0; i < dataset.numAttributes(); i++) {
            String nombreAtributo = dataset.attribute(i).name();
            if (dataset.attribute(i).isNumeric()) {
                switch (nombreAtributo) {
                    case "duration": valores.add(txtDuration.getText()); break;
                    case "credit_amount": valores.add(txtCreditAmount.getText()); break;
                    case "installment_commitment": valores.add(txtInstallmentRate.getText()); break;
                    case "residence_since": valores.add(txtResidenceDuration.getText()); break;
                    case "age": valores.add(txtAge.getText()); break;
                    case "existing_credits": valores.add(txtExistingCredits.getText()); break;
                    case "num_dependents": valores.add(txtDependents.getText()); break;
                    default: valores.add("0");
                }
            } else {
                JComboBox<String> comboBox = obtenerComboBoxPorAtributo(nombreAtributo);
                if (comboBox != null) {
                    valores.add((String) comboBox.getSelectedItem());
                } else {
                    valores.add(dataset.attribute(i).value(0));
                }
            }
        }
        return valores;
    }

    private void clasificar() {
        if (!validarCamposNumericos()) {
            return;
        }

        try {
            ArrayList<String> valores = recogerValores();
            String resultado = clasificador.clasificarInstancia(valores);
            txtResultado.setText(resultado);
        } catch (Exception e) {
            mostrarError("Error al clasificar: " + e.getMessage());
        }
    }

    private boolean validarCamposNumericos() {
        try {
            if (!txtDuration.getText().trim().isEmpty())
                Integer.parseInt(txtDuration.getText().trim());
            if (!txtCreditAmount.getText().trim().isEmpty())
                Double.parseDouble(txtCreditAmount.getText().trim());
            if (!txtInstallmentRate.getText().trim().isEmpty())
                Integer.parseInt(txtInstallmentRate.getText().trim());
            if (!txtResidenceDuration.getText().trim().isEmpty())
                Integer.parseInt(txtResidenceDuration.getText().trim());
            if (!txtAge.getText().trim().isEmpty())
                Integer.parseInt(txtAge.getText().trim());
            if (!txtExistingCredits.getText().trim().isEmpty())
                Integer.parseInt(txtExistingCredits.getText().trim());
            if (!txtDependents.getText().trim().isEmpty())
                Integer.parseInt(txtDependents.getText().trim());
            return true;
        } catch (NumberFormatException e) {
            mostrarError("Por favor, ingrese valores numéricos válidos");
            return false;
        }
    }

    private void actualizarGrafico(double precision, double error) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(precision, "Métricas", "Precisión");
        dataset.addValue(error, "Métricas", "Error");

        JFreeChart chart = ChartFactory.createBarChart(
                "Rendimiento del Modelo Random Forest",
                "Métrica",
                "Porcentaje",
                dataset
        );

        panelGrafico.removeAll();
        panelGrafico.add(new ChartPanel(chart));
        panelGrafico.revalidate();
    }

    private void limpiarCampos() {
        txtDuration.setText("");
        txtCreditAmount.setText("");
        txtInstallmentRate.setText("");
        txtResidenceDuration.setText("");
        txtAge.setText("");
        txtExistingCredits.setText("");
        txtDependents.setText("");

        if (cmbCheckingStatus.getItemCount() > 0) cmbCheckingStatus.setSelectedIndex(0);
        if (cmbCreditHistory.getItemCount() > 0) cmbCreditHistory.setSelectedIndex(0);
        if (cmbPurpose.getItemCount() > 0) cmbPurpose.setSelectedIndex(0);
        if (cmbSavingsStatus.getItemCount() > 0) cmbSavingsStatus.setSelectedIndex(0);
        if (cmbEmployment.getItemCount() > 0) cmbEmployment.setSelectedIndex(0);
        if (cmbPersonalStatus.getItemCount() > 0) cmbPersonalStatus.setSelectedIndex(0);
        if (cmbOtherDebtors.getItemCount() > 0) cmbOtherDebtors.setSelectedIndex(0);
        if (cmbProperty.getItemCount() > 0) cmbProperty.setSelectedIndex(0);
        if (cmbInstallmentPlans.getItemCount() > 0) cmbInstallmentPlans.setSelectedIndex(0);
        if (cmbHousing.getItemCount() > 0) cmbHousing.setSelectedIndex(0);
        if (cmbJob.getItemCount() > 0) cmbJob.setSelectedIndex(0);
        if (cmbTelephone.getItemCount() > 0) cmbTelephone.setSelectedIndex(0);
        if (cmbForeignWorker.getItemCount() > 0) cmbForeignWorker.setSelectedIndex(0);

        txtResultado.setText("");
        panelGrafico.removeAll();
        panelGrafico.revalidate();
        panelGrafico.repaint();
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            FormularioRandomForest formulario = new FormularioRandomForest();
            formulario.setVisible(true);
        });
    }
}