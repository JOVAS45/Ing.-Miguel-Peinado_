package clasificacionweka;

import weka.classifiers.trees.J48;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.classifiers.Evaluation;
import weka.core.SerializationHelper;
import java.util.ArrayList;
import java.util.Random;

public class ClasificacionJ48 {
    private J48 clasificador;
    private Instances datos;
    private StringBuilder resultadosEntrenamiento;
    private double precision;
    private double error;

    public void cargarDatos(String rutaArchivo) {
        try {
            DataSource fuente = new DataSource(rutaArchivo);
            datos = fuente.getDataSet();

            if (datos.classIndex() == -1) {
                datos.setClassIndex(datos.numAttributes() - 1);
            }

            resultadosEntrenamiento = new StringBuilder();
            resultadosEntrenamiento.append("=== Información del Dataset ===\n");
            resultadosEntrenamiento.append("Nombre del dataset: " + datos.relationName() + "\n");
            resultadosEntrenamiento.append("Número de instancias: " + datos.numInstances() + "\n");
            resultadosEntrenamiento.append("Número de atributos: " + datos.numAttributes() + "\n\n");
            resultadosEntrenamiento.append("Atributos:\n");
            for (int i = 0; i < datos.numAttributes(); i++) {
                resultadosEntrenamiento.append((i+1) + ". " + datos.attribute(i).name() +
                        (i == datos.classIndex() ? " (clase)" : "") + "\n");
            }

        } catch (Exception e) {
            throw new RuntimeException("Error al cargar datos: " + e.getMessage());
        }
    }

    public void entrenarModelo() {
        try {
            clasificador = new J48();
            clasificador.setUnpruned(false);
            clasificador.setConfidenceFactor(0.25f);
            clasificador.setMinNumObj(2);

            long tiempoInicio = System.currentTimeMillis();
            clasificador.buildClassifier(datos);
            long tiempoFin = System.currentTimeMillis();

            // Evaluar el modelo
            Evaluation eval = new Evaluation(datos);
            eval.crossValidateModel(clasificador, datos, 10, new Random(1));

            // Guardar métricas
            precision = eval.pctCorrect();
            error = eval.pctIncorrect();

            // Construir resultado
            resultadosEntrenamiento.append("\n=== Modelo Generado ===\n");
            resultadosEntrenamiento.append("Tiempo de entrenamiento: " + (tiempoFin - tiempoInicio) + "ms\n");
            resultadosEntrenamiento.append("\nÁrbol de decisión J48:\n");
            resultadosEntrenamiento.append(clasificador.toString() + "\n");
            resultadosEntrenamiento.append("\n=== Resultados de la Evaluación ===\n");
            resultadosEntrenamiento.append("Precisión: " + String.format("%.2f%%", precision) + "\n");
            resultadosEntrenamiento.append("Error: " + String.format("%.2f%%", error) + "\n");
            resultadosEntrenamiento.append("\nMatriz de confusión:\n");
            resultadosEntrenamiento.append(eval.toMatrixString());

        } catch (Exception e) {
            throw new RuntimeException("Error al entrenar modelo: " + e.getMessage());
        }
    }

    public String clasificarInstancia(ArrayList<String> valores) {
        try {
            if (clasificador == null) {
                return "Error: El modelo no ha sido entrenado";
            }

            Instance instancia = new weka.core.DenseInstance(datos.numAttributes());
            instancia.setDataset(datos);

            // Establecer los valores de la instancia
            for (int i = 0; i < valores.size() && i < datos.numAttributes(); i++) {
                if (datos.attribute(i).isNumeric()) {
                    try {
                        double valor = Double.parseDouble(valores.get(i));
                        instancia.setValue(i, valor);
                    } catch (NumberFormatException e) {
                        return "Error: El valor '" + valores.get(i) + "' debe ser numérico";
                    }
                } else {
                    instancia.setValue(datos.attribute(i), valores.get(i));
                }
            }

            // Realizar la clasificación
            double resultado = clasificador.classifyInstance(instancia);
            return datos.classAttribute().value((int) resultado);

        } catch (Exception e) {
            return "Error en la clasificación: " + e.getMessage();
        }
    }

    public void guardarModelo(String rutaArchivo) {
        try {
            SerializationHelper.write(rutaArchivo, clasificador);
        } catch (Exception e) {
            throw new RuntimeException("Error al guardar el modelo: " + e.getMessage());
        }
    }

    public void cargarModeloGuardado(String rutaArchivo) {
        try {
            clasificador = (J48) SerializationHelper.read(rutaArchivo);
        } catch (Exception e) {
            throw new RuntimeException("Error al cargar el modelo: " + e.getMessage());
        }
    }

    public String obtenerResultadosEntrenamiento() {
        return resultadosEntrenamiento.toString();
    }

    public double getPrecision() {
        return precision;
    }

    public double getError() {
        return error;
    }

    public Instances getDatos() {
        return datos;
    }
}